# Project Title: Capacity Counter
#### Video Demo: https://youtu.be/2VmucU5f_e0
#### Description:
The intent of this project was to create a counter for small local businesses to keep track
of how many people are in their store. This idea was inspired by the aftermath of COVID-19
and how it affected many local businesses as there were many capacity restrictions for
small businesses. Thus, I created this app to help local business owners keep track of the number
of people in their store to keep everybody safe while keeping their business afloat.

Note: This project was created using Android Studio. 
This capacity counter has a settings page that allows the user to update the maximum number of people
in the store, reset to default settings, and reset the counter to 0. This is what the SettingsActivity.java 
class does. 

Depending on the number of people in the store and its closeness to the maximum capacity, there is coloured
text that indicates the current state of the store, whether it is under, approaching, at, or over capacity.
There are two buttons on the main screen to control the amount of people entering and leaving the store.
A notification will appear at the bottom of the screen indicating if the store is over capacity.
This is what the MainActivity.java class does.

The AndroidSaveState class saves the user input of maximum capacity of the store, the number of people in the
store, and the stage of the store. This is designed to ensure that the data in the main activity screen is
saved when the user is tinkering with the settings page.

A feature that can be added onto this project is having multiple devices controlling one counter,
as this app is ideally suited for businesses with one entrance and exit. Nonetheless, I had fun creating this
application and grateful for the opportunity to pursue my passions in computer science by taking CS50.