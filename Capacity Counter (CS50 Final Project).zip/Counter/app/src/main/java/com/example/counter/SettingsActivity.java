package com.example.counter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SettingsActivity extends AppCompatActivity {

    private String newCapacity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
    }

    /**
     * Purpose: Updates the maximum capacity of the store based on user input
     * Pre: User inputted a number in the text field and clicked the "update maximum capacity" button
     * Post: User is redirected back to the main application with the maximum capacity updated
     * @param v
     */

    public void updateCapacity(View v) {
        Intent i = new Intent(this, MainActivity.class);
        TextView t = findViewById(R.id.editTextNumber);
        newCapacity = t.getText().toString();
        MainActivity.saveState.setMaxCapacity(newCapacity);
        startActivity(i);
    }

    /**
     * Purpose: Resets the number of people in the store to 0
     * Pre: The "Reset" button is clicked
     * Post: User is redirected to the main application with the counter set to 0
     * @param v
     */
    public void resetCounter(View v) {
        Intent i = new Intent(this, MainActivity.class);
        MainActivity.saveState.setCustomersInStore("0");
        startActivity(i);
    }

    /**
     * Purpose: The default settings is applied to the application
     * Pre: The "Reset to Default" button is clicked
     * Post: User is redirected to the main application with default settings applied.
     * Default settings is defined as what the user sees when launching the app.
     * @param v
     */
    public void backToDefault(View v) {
        Intent i = new Intent(this, MainActivity.class);
        MainActivity.saveState.reset();
        startActivity(i);
    }



}