package com.example.counter;

import android.app.Application;

public class AndroidSaveState extends Application {
    private String customersInStore;
    private String maxCapacity;
    private String storeStage;

    public AndroidSaveState() {
        this.customersInStore = "0";
        this.maxCapacity = "25";
        this.storeStage = "under capacity.";
    }

    public String getCustomersInStore() {
        return customersInStore;
    }

    public String getMaxCapacity() {
        return maxCapacity;
    }

    public String getStoreStage() {
        return storeStage;
    }

    public void setCustomersInStore (String customersInStore) {
        this.customersInStore = customersInStore;
    }

    public void setMaxCapacity(String maxCapacity) {
        this.maxCapacity = maxCapacity;
    }

    public void setStoreStage(String storeStage) {
        this.storeStage = storeStage;
    }

    public void reset() {
        customersInStore = "0";
        maxCapacity = "25";
        storeStage = "under capacity.";
    }


}
