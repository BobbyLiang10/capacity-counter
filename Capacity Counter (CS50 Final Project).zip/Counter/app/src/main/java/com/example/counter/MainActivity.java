package com.example.counter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Constants for stage of store depending on capacity

    private final String stage1 = "under capacity.";
    private final String stage2 = "approaching capacity.";
    private final String stage3 = "at capacity.";
    private final String stage4 = "over capacity.";

    // Buttons on the main interface
    Button increment;
    Button decrement;
    Button settings;

    // Variables storing contents of user inputted data
    private String originalNum;
    private int peopleInStore;
    private String stage;
    private int maxCapacity;

    public static AndroidSaveState saveState;

    TextView peopleInStoreText;
    TextView maxCapacityText;
    TextView currentStageText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        saveState = (AndroidSaveState) getApplication();

        increment = (Button) findViewById (R.id.add);
        decrement = (Button) findViewById (R.id.subtract);
        settings = (Button) findViewById(R.id.configureSettings);
        peopleInStoreText = (TextView) findViewById(R.id.peopleInStore);
        maxCapacityText = (TextView) findViewById(R.id.maxCapNum);
        currentStageText = (TextView) findViewById(R.id.storeStage);

        // When the increment or decrement button is clicked, call two methods
        increment.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                increment(v);
                setStage(v);
            }
        });

        decrement.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                decrement(v);
                setStage(v);
            }
        });

        loadContent();
        setupListeners();
    }

    /**
     * Purpose: Saves the current state of the app before the user presses the settings button
     * Pre: The settings button was clicked
     * Post: All user data is saved and the user is now on the settings page
     */
    private void setupListeners() {
        settings.setOnClickListener(new View.OnClickListener () {
            public void onClick (View v) {

                // Obtaining the information in the current state of the app
                String customersInStore = peopleInStoreText.getText().toString();
                String maxCapacity = maxCapacityText.getText().toString();
                String storeStage = currentStageText.getText().toString();

                // Saving user input or default settings to SaveState
                saveState.setCustomersInStore(customersInStore);
                saveState.setMaxCapacity(maxCapacity);
                saveState.setStoreStage(storeStage);

                launchSettings(v);
            }
        });
    }

    /**
     * Purpose: Loads the information of the app after returning from the settings interface
     */
    private void loadContent() {
        peopleInStoreText.setText(saveState.getCustomersInStore());
        maxCapacityText.setText(saveState.getMaxCapacity());
        currentStageText.setText(saveState.getStoreStage());

        peopleInStore = Integer.parseInt(peopleInStoreText.getText().toString());
        maxCapacity = Integer.parseInt(maxCapacityText.getText().toString());
        stage = currentStageText.getText().toString();
    }

    /**
     * Purpose: Launch the settings page
     * @param v
     * Pre: Settings button is clicked
     * Post: The user is on the settings page
     */
    public void launchSettings(View v) {
        Intent i = new Intent(this, SettingsActivity.class);
        startActivity(i);
    }

    /**
     * Purpose: Add one to the current counter of people in the store
     * Pre: The increment button is clicked
     * Post: The number is updated on @param v and displays the updated counter
     */
    public void increment(View v) {
        TextView t = findViewById(R.id.peopleInStore);
        originalNum = t.getText().toString();
        peopleInStore = Integer.parseInt(originalNum) + 1;
        t.setText(Integer.toString(peopleInStore));
        if (overCapacity (peopleInStore)) {
            Toast.makeText(this, "Store is over capacity limit!", Toast.LENGTH_LONG).show();
            t.setTextColor(Color.RED);
        } else {
            t.setTextColor(Color.GREEN);
        }
        Log.d("info", originalNum);
    }

    /**
     * Purpose: Subtract one to the current counter of people in the store
     * Pre: The decrement button is clicked
     * Post: The number is updated on @param v and displays the updated counter
     */
    public void decrement(View v) {
        TextView t = findViewById(R.id.peopleInStore);
        originalNum = t.getText().toString();
        peopleInStore = Integer.parseInt(originalNum) - 1;
        if (peopleInStore <= maxCapacity) {
            t.setTextColor(Color.GREEN);
        } else {
            t.setTextColor(Color.RED);
        }

        if (isNegative (peopleInStore)) {
            Toast.makeText(this, "Counter cannot be negative!", Toast.LENGTH_LONG).show();
        } else {
            t.setText(Integer.toString(peopleInStore));
            Log.d("info", originalNum);
        }
    }

    /**
     * Purpose: Determines whether the number of people in the store is greater than the maximum
     *          capacity
     * Pre: none
     * Post: Returns true if @param count is greater than maxCapacity, false otherwise
     */
    public boolean overCapacity(int count) {
        if (count > maxCapacity) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Purpose: Determines whether or not the number of people in the store is less than 0
     * Pre: none
     * Post: Returns true if @param count is less than 0, false otherwise
     */
    public boolean isNegative(int count) {
        if (count < 0) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Purpose: Sets the correct stage for the store
     * Pre: none
     * Post: @param v is updated and the correct message for the stage of the store is displayed
     */
    public void setStage(View v) {
        TextView t = findViewById(R.id.peopleInStore);
        TextView m = findViewById(R.id.storeStage);
        stage = m.getText().toString();
        originalNum = t.getText().toString();
        int intOriginalNum = Integer.parseInt(originalNum);
        // If the number of people in the store is less than 75% of the maximum capacity,
        //  the store is in stage 1 and the text is green.
        if (intOriginalNum < (0.75 * maxCapacity)) {
            stage = stage1;
            m.setTextColor(Color.GREEN);
        // If the number of people in the store is less than 75% of the maximum capacity,
        //  but less than the maximum capacity, the store is in stage 2 and the text is magenta.
        } else if (intOriginalNum > (0.75 * maxCapacity) && (intOriginalNum < maxCapacity)) {
            stage = stage2;
            m.setTextColor(Color.MAGENTA);
        // If the number of people in the store is equal to the maximum capacity, the store is in
        // stage 3 and the text is red.
        } else if (intOriginalNum == maxCapacity) {
            stage = stage3;
            m.setTextColor(Color.RED);
        // Otherwise, the number of people in the store has exceeded the maximum capacity
        // The store is in stage 4 and the user is notified with red text on both the counter and
        // store stage message.
        } else {
            stage = stage4;
            m.setTextColor(Color.RED);
        }
        m.setText(stage);
        // saves the current message
        saveState.setStoreStage(stage);
    }
}